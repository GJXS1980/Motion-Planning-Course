#ifndef _NODE_H_
#define _NODE_H_

#include <iostream>
#include <ros/ros.h>
#include <ros/console.h>
#include <Eigen/Eigen>
#include "backward.hpp"

#define inf 1>>20
struct GridNode;
typedef GridNode* GridNodePtr;

struct GridNode
{     
    std::multimap<double, GridNodePtr>::iterator nodeMapIt;

    GridNode(){};
    ~GridNode(){};
};


#endif
